# monsterMakerImporter
A module for Foundry VTT to help import monster made in Giffyglyph's Monster Maker
